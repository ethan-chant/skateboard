import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Constants
g = 9.81  # gravity (m/s^2)
mu = 0.1  # coefficient of friction
mass = 5  # mass of the skateboard (kg)
angle = 30  # angle of ramp in degrees
time_step = 0.01  # time step (s)
total_time = 5  # total time of simulation (s)

# Convert angle to radians
theta = np.radians(angle)

# Initial conditions
initial_velocity = 0  # initial velocity (m/s)
initial_position = 0  # initial position (m)

# Forces
normal_force = mass * g * np.cos(theta)  # normal force (N)
friction_force = mu * normal_force  # friction force (N)
gravity_force = mass * g * np.sin(theta)  # component of gravity along the ramp (N)
net_force = gravity_force - friction_force  # net force along the ramp (N)

# Acceleration
acceleration = net_force / mass  # acceleration (m/s^2)

# Time vector
time = np.arange(0, total_time, time_step)

# Motion Equations
velocity = initial_velocity + acceleration * time
position = initial_position + initial_velocity * time + 0.5 * acceleration * time**2

# Plotting
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Create ramp surface
x_ramp = position * np.sin(theta)
y_ramp = position * np.cos(theta)
z_ramp = np.zeros_like(x_ramp)

ax.plot(x_ramp, y_ramp, z_ramp, label='Skateboard Path')
ax.set_xlabel('X Position (m)')
ax.set_ylabel('Y Position (m)')
ax.set_zlabel('Z Position (m)')
ax.set_title('3D Trajectory of Skateboard on Ramp')
ax.legend()

plt.show()
